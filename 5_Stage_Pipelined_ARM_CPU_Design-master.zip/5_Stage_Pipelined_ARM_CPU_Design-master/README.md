# 5-stage Pipelined ARM-based CPU Design in Verilog

![Alt text](https://github.tamu.edu/thuyng88/Single_Core_5_Stage_Pipeline_CPU_Design/blob/master/IMG_0147.PNG?raw=true "RISC single core processor diagram")
ARM-based processor diagram
